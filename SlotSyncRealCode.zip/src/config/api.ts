/**
 * API Configuration for SlotSync
 * 
 * CRITICAL: EXPO_PUBLIC_API_BASE_URL MUST be set for the app to work!
 * 
 * Physical devices CANNOT reach localhost - they need your computer's LAN IP.
 * 
 * To configure:
 * 1. Create a .env file in the project root
 * 2. Add: EXPO_PUBLIC_API_BASE_URL=http://192.168.x.x:3000
 *    (Replace 192.168.x.x with your computer's IP address)
 * 3. Find your IP: 
 *    - Mac: System Settings > Network > Wi-Fi > Details > IP Address
 *    - Or run: ifconfig | grep "inet " | grep -v 127.0.0.1
 * 
 * For local development:
 * - iOS Simulator: http://localhost:3000 (only works in simulator!)
 * - Android Emulator: http://10.0.2.2:3000 (only works in emulator!)
 * - Physical device: http://YOUR_COMPUTER_IP:3000 (REQUIRED for real devices!)
 */

const getApiBaseUrl = (): string => {
  // CRITICAL: Require EXPO_PUBLIC_API_BASE_URL - no fallback to localhost
  const baseUrl = process.env.EXPO_PUBLIC_API_BASE_URL;
  
  if (!baseUrl) {
    const errorMessage = `
═══════════════════════════════════════════════════════════════
❌ API BASE URL NOT CONFIGURED
═══════════════════════════════════════════════════════════════

EXPO_PUBLIC_API_BASE_URL is required but not set!

Physical devices CANNOT reach localhost. You must set your 
computer's LAN IP address.

To fix:
1. Find your computer's IP address:
   Mac: System Settings > Network > Wi-Fi > Details > IP Address
   Or run: ifconfig | grep "inet " | grep -v 127.0.0.1

2. Create a .env file in the project root with:
   EXPO_PUBLIC_API_BASE_URL=http://YOUR_IP:3000
   
   Example: EXPO_PUBLIC_API_BASE_URL=http://192.168.1.100:3000

3. Restart Expo (stop and run 'npx expo start' again)

═══════════════════════════════════════════════════════════════
`;
    console.error(errorMessage);
    throw new Error('EXPO_PUBLIC_API_BASE_URL is not set. See console for setup instructions.');
  }

  // Validate that it's not localhost (won't work on physical devices)
  if (baseUrl.includes('localhost') || baseUrl.includes('127.0.0.1')) {
    console.warn(`
⚠️  WARNING: API base URL contains localhost/127.0.0.1
   This will NOT work on physical devices!
   Current URL: ${baseUrl}
   Use your computer's LAN IP instead (e.g., http://192.168.1.100:3000)
`);
  }

  // Normalize URL (remove trailing slash)
  return baseUrl.replace(/\/+$/, '');
};

export const API_CONFIG = {
  BASE_URL: getApiBaseUrl(),
  ENDPOINTS: {
    IDENTIFY_RECORD: '/api/identify-record',
    PING: '/api/ping',
  },
  TIMEOUT: 90000, // 90 seconds - increased for complex identifications
} as const;

/**
 * Constructs a full API URL from an endpoint
 * Handles leading/trailing slashes correctly
 */
export const getApiUrl = (endpoint: string): string => {
  const baseUrl = API_CONFIG.BASE_URL;
  const normalizedEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  
  // Ensure no double slashes (except after http://)
  const url = `${baseUrl}${normalizedEndpoint}`;
  return url.replace(/([^:]\/)\/+/g, '$1');
};

