import { DarkTheme as NavigationDarkTheme, Theme } from '@react-navigation/native';
import { colors } from './colors';
import { typography } from './typography';
import { radius, shadow } from './layout';

// CRITICAL: Define spacing directly here to break circular dependencies
// This ensures spacing is always initialized before theme object is created
export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  xxl: 32,
};

// Static theme object used app-wide
// CRITICAL: Ensure spacing is always available - use direct reference, not import
export const theme = {
  colors,
  typography,
  spacing: spacing, // Always defined - direct reference to const above (never undefined)
  radius,
  shadow,
};

// Verify spacing is always available (runtime check)
if (!theme.spacing) {
  console.error('[theme] CRITICAL: spacing is missing from theme object!', theme);
  // Force spacing to be available
  (theme as any).spacing = spacing;
}

export type AppTheme = typeof theme;

// React Navigation theme object
export const navTheme: Theme = {
  ...NavigationDarkTheme,
  colors: {
    ...NavigationDarkTheme.colors,
    primary: colors.accent,
    background: colors.background,
    card: colors.backgroundMuted,
    text: colors.textPrimary,
    border: colors.borderSubtle,
    notification: colors.accent,
  },
};
