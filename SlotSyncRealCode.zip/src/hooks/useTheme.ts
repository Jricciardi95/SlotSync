// src/hooks/useTheme.ts
import { theme, spacing, type AppTheme } from '../theme';

// Hook that returns our static theme object.
// Later we can switch this to a real React context if we want live theming.
export const useTheme = (): AppTheme => {
  // CRITICAL: Defensive check - ensure spacing always exists
  // This fixes circular dependency issues where spacing might be undefined
  if (!theme || !theme.spacing) {
    console.error('[useTheme] ERROR: theme or theme.spacing is missing!', {
      hasTheme: !!theme,
      hasSpacing: !!theme?.spacing,
      themeKeys: theme ? Object.keys(theme) : [],
    });
    
    // Return a fallback theme with spacing - use direct import as backup
    const fallbackTheme = {
      colors: theme?.colors || {},
      typography: theme?.typography || {},
      spacing: spacing || { // Use direct spacing import as ultimate fallback
        xs: 4,
        sm: 8,
        md: 12,
        lg: 16,
        xl: 24,
        xxl: 32,
      },
      radius: theme?.radius || {},
      shadow: theme?.shadow || {},
    } as AppTheme;
    
    return fallbackTheme;
  }
  
  // Double-check spacing is available (defensive)
  if (!theme.spacing) {
    console.warn('[useTheme] WARNING: theme.spacing is undefined, using fallback');
    (theme as any).spacing = spacing;
  }
  
  return theme;
};
