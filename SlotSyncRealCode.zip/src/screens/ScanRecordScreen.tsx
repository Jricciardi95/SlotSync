import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  Animated,
  Image,
} from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import { AppScreen } from '../components/AppScreen';
import { AppCard } from '../components/AppCard';
import { AppText } from '../components/AppText';
import { AppButton } from '../components/AppButton';
import { useTheme } from '../hooks/useTheme';
import { LibraryStackParamList } from '../navigation/types';
import {
  identifyRecord,
  identifyRecordByBarcode,
  IdentificationMatch,
  IdentificationError,
  normalizeScanResult,
  ScanResult,
} from '../services/RecordIdentificationService';
import { convertToJpeg } from '../utils/imageConverter';
import { createRecord, findDuplicateRecord, createTrack } from '../data/repository';
import { Ionicons } from '@expo/vector-icons';
import { AppIconButton } from '../components/AppIconButton';

type Props = NativeStackScreenProps<LibraryStackParamList, 'ScanRecord'>;

export const ScanRecordScreen: React.FC<Props> = ({ navigation, route }) => {
  const { colors, spacing, radius } = useTheme();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanning, setScanning] = useState(false);
  const [capturedUri, setCapturedUri] = useState<string | null>(null);
  const [identifying, setIdentifying] = useState(false);
  const [capturing, setCapturing] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [selectedSuggestion, setSelectedSuggestion] = useState<IdentificationMatch | null>(null);
  const [suggestions, setSuggestions] = useState<{
    candidates: IdentificationMatch[];
    extractedText?: string;
  } | null>(null);
  const [scanMode, setScanMode] = useState<'image' | 'barcode'>('image'); // NEW: Barcode scanning mode
  const scanLineAnim = useRef(new Animated.Value(0)).current;
  const abortControllerRef = useRef<AbortController | null>(null);
  const cameraRef = useRef<CameraView | null>(null);
  useEffect(() => {
    if (scanning) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(scanLineAnim, {
            toValue: 1,
            duration: 2000,
            useNativeDriver: true,
          }),
          Animated.timing(scanLineAnim, {
            toValue: 0,
            duration: 0,
            useNativeDriver: true,
          }),
        ])
      ).start();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scanning]);

  if (!permission) {
    return (
      <AppScreen title="Camera">
        <View style={styles.centerContent}>
          <ActivityIndicator size="large" color={colors.accent} />
        </View>
      </AppScreen>
    );
  }

  if (!permission.granted) {
    return (
      <AppScreen title="Camera Permission">
        <AppCard>
          <AppText variant="body" style={{ marginBottom: spacing.md }}>
            We need camera access to scan album covers.
          </AppText>
          <AppButton title="Grant Permission" onPress={requestPermission} />
        </AppCard>
      </AppScreen>
    );
  }

  const handleCancel = () => {
    // Cancel any ongoing identification request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    
    // Reset state
    setCapturedUri(null);
    setResult(null);
    setSelectedSuggestion(null);
    setIdentifying(false);
    setScanning(true);
  };

  const handleManualCapture = async () => {
    if (capturing || capturedUri) return;

    setCapturing(true);
    setScanning(false);

    try {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      
      // Try to use CameraView's takePictureAsync if available
      let photoUri: string | null = null;
      
      if (cameraRef.current) {
        try {
          // Try to call takePictureAsync on the camera ref
          const camera = cameraRef.current as any;
          if (camera.takePictureAsync) {
            const photo = await camera.takePictureAsync({
              quality: 1.0, // Maximum quality for better OCR/recognition
              base64: false,
              skipProcessing: false, // Keep image processing for better results
              exif: false, // Don't need EXIF data
            });
            photoUri = photo?.uri || null;
          }
        } catch (err) {
          console.log('CameraView takePictureAsync not available, using ImagePicker fallback');
        }
      }

      // Fallback to ImagePicker if CameraView method didn't work
      if (!photoUri) {
        const { status } = await ImagePicker.requestCameraPermissionsAsync();
        if (status !== 'granted') {
          throw new Error('Camera permission not granted');
        }

        const result = await ImagePicker.launchCameraAsync({
          mediaTypes: ImagePicker.MediaTypeOptions.Images,
          allowsEditing: false,
          quality: 1.0, // Maximum quality for better OCR/recognition
          exif: false, // Don't need EXIF data
        });

        if (!result.canceled && result.assets?.[0]?.uri) {
          photoUri = result.assets[0].uri;
        }
      }

      if (photoUri) {
        // CRITICAL: Convert to JPEG before processing (HEIC → JPEG)
        console.log('[ScanRecord] Converting captured image to JPEG...');
        const jpegUri = await convertToJpeg(photoUri, {
          maxWidth: 1200,
          quality: 0.8,
        });
        console.log('[ScanRecord] ✅ Image converted to JPEG, using:', jpegUri);
        await handleCapture(jpegUri);
      } else {
        // No image captured - reset
        setScanning(true);
      }
    } catch (error) {
      console.error('Capture failed', error);
      // Reset on error
      setScanning(true);
    } finally {
      setCapturing(false);
    }
  };

  const handleCapture = async (uri: string) => {
    setCapturedUri(uri);
    setScanning(false);
    setIdentifying(true);

    // Create abort controller for this request
    abortControllerRef.current = new AbortController();

    try {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      const response = await identifyRecord(uri, abortControllerRef.current.signal);
      console.log('[ScanRecord] Identification response:', {
        artist: response.bestMatch.artist,
        title: response.bestMatch.title,
        year: response.bestMatch.year,
        tracksCount: response.bestMatch.tracks?.length || 0,
        tracks: response.bestMatch.tracks,
        confidence: response.confidence,
        hasTracks: !!response.bestMatch.tracks,
        tracksArray: JSON.stringify(response.bestMatch.tracks || []),
      });
      
      if (!response.bestMatch.tracks || response.bestMatch.tracks.length === 0) {
        console.warn('[ScanRecord] ⚠️ No tracks in response!');
        console.warn('[ScanRecord] Full response.bestMatch:', JSON.stringify(response.bestMatch, null, 2));
      } else {
        console.log(`[ScanRecord] ✅ Received ${response.bestMatch.tracks.length} tracks from API`);
        console.log('[ScanRecord] First track sample:', response.bestMatch.tracks[0]);
      }
      // Normalize response into ScanResult structure
      const normalizedResult = normalizeScanResult(response);
      setResult(normalizedResult);
      abortControllerRef.current = null;
    } catch (error: any) {
      // Don't show error if request was aborted
      if (abortControllerRef.current?.signal.aborted) {
        setIdentifying(false);
        return;
      }
      
      // CRITICAL: Treat LOW_CONFIDENCE with candidates as suggestions, not a hard error
      // This should open the Review Suggestions UI without scary red console errors
      if (error.code === 'LOW_CONFIDENCE') {
        const candidates = Array.isArray(error.candidates) ? error.candidates : [];
        
        // CRITICAL: Only show suggestions if we have valid album candidates
        // Backend should already filter, but be defensive - only use items with non-empty title
        const validCandidates = candidates.filter((c: any) => {
          return c && c.title && typeof c.title === 'string' && c.title.trim().length > 0;
        });
        
        if (validCandidates.length > 0) {
          // Soft path: show suggestions UI with album names only
          console.log(`[ScanRecord] Low confidence with ${validCandidates.length} album candidates - showing suggestions screen`);
          setSuggestions({
            candidates: validCandidates,
            extractedText: error.extractedText,
          });
          setIdentifying(false);
          return;
        }
        
        // No valid album candidates: skip suggestions UI and go straight to manual entry
        console.log(`[ScanRecord] Low confidence but no valid album candidates - showing manual entry prompt`);
        setIdentifying(false);
        Alert.alert(
          'Unable to Identify Record',
          'We couldn\'t identify this album with confidence. Would you like to enter the details manually?',
          [
            { 
              text: 'No', 
              style: 'cancel', 
              onPress: () => handleCancel()
            },
            {
              text: 'Yes',
              onPress: () => {
                navigation.navigate('AddRecord', { 
                  imageUri: uri || undefined,
                  initialArtist: error.extractedText?.split(' ')[0] || undefined,
                  initialTitle: error.extractedText?.split(' ').slice(1).join(' ') || undefined,
                });
              },
            },
          ]
        );
        return;
      }
      
      // Hard errors: log and show error UI
      console.error('[ScanRecord] Identification failed:', error);
      console.error('[ScanRecord] Error details:', {
        code: error.code,
        message: error.message,
        hasCandidates: !!error.candidates,
        candidatesCount: error.candidates?.length || 0,
        hasExtractedText: !!error.extractedText,
      });
      
      // Check if we have any extracted text or candidates to show (fallback for non-LOW_CONFIDENCE errors)
      if (error.extractedText || (error.candidates && error.candidates.length > 0)) {
        const candidates = error.candidates || [];
        if (candidates.length > 0) {
          console.log(`[ScanRecord] Found ${candidates.length} candidates from error - showing suggestions`);
          setSuggestions({
            candidates: candidates,
            extractedText: error.extractedText,
          });
          setIdentifying(false);
          return;
        }
      }
      
      // Show error message with details
      const errorMessage = error.message || 'Unknown error occurred';
      Alert.alert(
        'Unable to Identify Record',
        `${errorMessage}\n\nWould you like to enter the album details manually?`,
        [
          { 
            text: 'No', 
            style: 'cancel', 
            onPress: () => {
              setIdentifying(false);
              handleCancel();
            }
          },
          {
            text: 'Yes',
            onPress: () => {
              setIdentifying(false);
              navigation.navigate('AddRecord', { 
                imageUri: uri || undefined,
                initialArtist: error.extractedText?.split(' ')[0] || undefined,
                initialTitle: error.extractedText?.split(' ').slice(1).join(' ') || undefined,
              });
            },
          },
        ]
      );
    } finally {
      // CRITICAL: Always clear identifying state, no matter what happens
      setIdentifying(false);
      abortControllerRef.current = null;
    }
  };

  const handleTryAnotherMatch = () => {
    setResult(prev => {
      if (!prev || !Array.isArray(prev.alternates) || prev.alternates.length === 0) {
        return prev;
      }

      const [next, ...rest] = prev.alternates;

      // Put the current one back into the alternates list at the end
      const newAlternates = [...rest, prev.current];

      return {
        current: next,
        alternates: newAlternates,
      };
    });
  };

  const handleSave = async () => {
    if (!result?.current) return;

    try {
      const currentMatch = result.current;
      // Check for duplicate
      const duplicate = await findDuplicateRecord(
        currentMatch.artist,
        currentMatch.title
      );

      if (duplicate) {
        Alert.alert(
          'Album Already in Library',
          `"${currentMatch.artist} - ${currentMatch.title}" is already in your library. Add again?`,
          [
            { text: 'No', style: 'cancel' },
            {
              text: 'Yes',
              onPress: async () => {
                await saveRecord();
              },
            },
          ]
        );
        return;
      }

      await saveRecord();
    } catch (error) {
      console.error('Failed to save record', error);
      Alert.alert('Error', 'Could not save record.');
    }
  };

  const saveRecord = async () => {
    if (!result?.current) return;

    try {
      const currentMatch = result.current;
      
      // CRITICAL: Use unified image selection logic
      // If metadata lookup returned a coverImageRemoteUrl, use it and ignore user photo
      // Only use user photo if no metadata match exists
      const { prepareImageFields } = require('../utils/imageSelection');
      const imageFields = prepareImageFields(
        currentMatch.coverImageRemoteUrl,
        capturedUri
      );
      
      const newRecord = await createRecord({
        title: currentMatch.title,
        artist: currentMatch.artist,
        year: currentMatch.year ?? null,
        coverImageRemoteUrl: imageFields.coverImageRemoteUrl,
        coverImageLocalUri: imageFields.coverImageLocalUri,
      });

      // Save tracks if available - CRITICAL: This must happen for tracks to appear
      if (currentMatch.tracks && currentMatch.tracks.length > 0) {
        console.log(`[ScanRecord] ✅ Attempting to save ${currentMatch.tracks.length} tracks for record ${newRecord.id}`);
        console.log(`[ScanRecord] Track list:`, currentMatch.tracks.map((t, i) => `${i + 1}. ${t.title}`).join(', '));
        let savedCount = 0;
        let failedCount = 0;
        for (const track of currentMatch.tracks) {
          try {
            if (!track.title || !track.title.trim()) {
              console.warn(`[ScanRecord] ⚠️ Skipping track with empty title`);
              continue;
            }
            await createTrack({
              recordId: newRecord.id,
              title: track.title.trim(),
              trackNumber: track.trackNumber ?? undefined,
              discNumber: track.discNumber ?? undefined,
              side: track.side ?? undefined,
              durationSeconds: track.durationSeconds ?? undefined,
            });
            savedCount++;
            console.log(`[ScanRecord] ✅ Saved track ${savedCount}: "${track.title}"`);
          } catch (error) {
            failedCount++;
            console.error(`[ScanRecord] ❌ Failed to save track "${track.title}":`, error);
            // Continue saving other tracks even if one fails
          }
        }
        if (savedCount > 0) {
          console.log(`[ScanRecord] ✅ Successfully saved ${savedCount}/${currentMatch.tracks.length} tracks`);
        }
        if (failedCount > 0) {
          console.warn(`[ScanRecord] ⚠️ Failed to save ${failedCount} tracks`);
        }
      } else {
        console.warn(`[ScanRecord] ⚠️ No tracks to save!`);
        console.warn(`[ScanRecord] currentMatch.tracks:`, currentMatch.tracks);
        console.warn(`[ScanRecord] tracks type:`, typeof currentMatch.tracks);
        console.warn(`[ScanRecord] tracks length:`, currentMatch.tracks?.length);
      }

      // Reset state
      setResult(null);
      setCapturedUri(null);
      
      Alert.alert('Success', 'Record added to library!', [
        { 
          text: 'OK', 
          onPress: () => {
            // Navigate and ensure library refreshes
            navigation.navigate('LibraryHome');
            // Also go back to allow library to refresh on focus
            setTimeout(() => navigation.goBack(), 100);
          }
        },
      ]);
    } catch (error) {
      console.error('Failed to save record', error);
      Alert.alert('Error', 'Could not save record.');
    }
  };

  const scanLineTranslateY = scanLineAnim.interpolate({
    inputRange: [0, 1],
    outputRange: [0, 400],
  });

  if (result?.current) {
    const currentMatch = result.current;
    const hasAlternates = Array.isArray(result.alternates) && result.alternates.length > 0;
    
    return (
      <AppScreen title="Confirm Match">
        <View style={styles.screenContainer}>
          <View style={styles.headerActions}>
            <AppIconButton
              name="close"
              onPress={handleCancel}
            />
          </View>
          <AppCard>
          <AppText variant="subtitle" style={{ marginBottom: spacing.md }}>
            Best Match
          </AppText>
          {(() => {
            const { getCoverImageUri } = require('../utils/imageSelection');
            const imageUri = getCoverImageUri(currentMatch.coverImageRemoteUrl, capturedUri);
            return imageUri ? (
              <Image
                source={{ uri: imageUri }}
                style={[styles.matchCover, { borderRadius: radius.md }]}
              />
            ) : null;
          })()}
          <AppText variant="body" style={{ marginTop: spacing.sm }}>
            {currentMatch.artist}
          </AppText>
          <AppText variant="body" style={{ marginBottom: spacing.md }}>
            {currentMatch.title}
          </AppText>
          {currentMatch.year && (
            <AppText variant="caption" style={{ marginBottom: spacing.md }}>
              {currentMatch.year}
            </AppText>
          )}

          <View style={styles.actions}>
            <AppButton
              title="Enter Details Manually"
              variant="ghost"
              onPress={() =>
                navigation.navigate('AddRecord', { imageUri: capturedUri || undefined })
              }
              style={{ flex: 1 }}
            />
            {hasAlternates && (
              <AppButton
                title="Try Another Match"
                variant="secondary"
                onPress={handleTryAnotherMatch}
                style={{ flex: 1, marginLeft: spacing.sm }}
              />
            )}
            <AppButton
              title="Looks Good"
              onPress={handleSave}
              style={{ flex: 1, marginLeft: spacing.sm }}
            />
          </View>
        </AppCard>
        </View>
      </AppScreen>
    );
  }

  // Low-confidence review UI for record suggestions
  if (suggestions && suggestions.candidates.length > 0) {
    return (
      <AppScreen title="Review Suggestions">
        <View style={styles.screenContainer}>
          <View style={styles.headerActions}>
            <AppIconButton
              name="close"
              onPress={() => {
                setSuggestions(null);
                handleCancel();
              }}
            />
          </View>
          <AppCard>
            <AppText variant="subtitle" style={{ marginBottom: spacing.sm }}>
              We found some possible matches:
            </AppText>
            {suggestions.extractedText && (
              <View style={{ marginBottom: spacing.md, padding: spacing.sm, backgroundColor: colors.backgroundMuted, borderRadius: radius.sm }}>
                <AppText variant="caption" style={{ color: colors.textMuted, fontSize: 11 }}>
                  Extracted text: "{suggestions.extractedText.length > 120 
                    ? suggestions.extractedText.substring(0, 120) + '...' 
                    : suggestions.extractedText}"
                </AppText>
              </View>
            )}
            <View style={{ gap: spacing.sm, marginBottom: spacing.md }}>
              {suggestions.candidates
                .filter((candidate: any) => {
                  // Defensive: Only render candidates with valid title (backend should already filter, but be safe)
                  return candidate && candidate.title && typeof candidate.title === 'string' && candidate.title.trim().length > 0;
                })
                .slice(0, 5)
                .map((candidate, idx) => {
                  // Format as "Artist – Title" or just "Title" if no artist
                  // CRITICAL: Only show album names, never URLs, article titles, etc.
                  const label = candidate.artist && candidate.artist.trim()
                    ? `${candidate.artist.trim()} – ${candidate.title.trim()}`
                    : candidate.title.trim();
                  
                  return (
                    <TouchableOpacity
                      key={idx}
                      style={[
                        styles.alternateItem,
                        {
                          backgroundColor: selectedSuggestion === candidate ? colors.accentMuted : colors.surfaceAlt,
                          borderColor: colors.borderSubtle,
                        },
                      ]}
                      onPress={() => setSelectedSuggestion(candidate)}
                    >
                      <AppText variant="body" style={{ fontWeight: '600' }}>{label}</AppText>
                      {candidate.confidence !== undefined && (
                        <AppText variant="caption" style={{ color: colors.textMuted, marginTop: spacing.xs }}>
                          Confidence: {Math.round(candidate.confidence * 100)}%
                        </AppText>
                      )}
                    </TouchableOpacity>
                  );
                })}
            </View>
            <View style={styles.actions}>
              <AppButton
                title="None of These"
                variant="ghost"
                onPress={() => {
                  setSuggestions(null);
                  navigation.navigate('AddRecord', { 
                    imageUri: capturedUri || undefined,
                    initialArtist: suggestions.extractedText?.split(' ')[0] || undefined,
                    initialTitle: suggestions.extractedText?.split(' ').slice(1).join(' ') || undefined,
                  });
                }}
                style={{ flex: 1 }}
              />
              <AppButton
                title="Use This"
                onPress={() => {
                  if (selectedSuggestion) {
                    // Create ScanResult from selected suggestion
                    const otherCandidates = suggestions.candidates.filter(c => 
                      c.artist !== selectedSuggestion.artist || c.title !== selectedSuggestion.title
                    );
                    setResult({
                      current: selectedSuggestion,
                      alternates: otherCandidates.slice(0, 2), // Max 2 alternates
                    });
                    setSuggestions(null);
                    setSelectedSuggestion(null);
                  }
                }}
                disabled={!selectedSuggestion}
                style={{ flex: 1, marginLeft: spacing.sm }}
              />
            </View>
          </AppCard>
        </View>
      </AppScreen>
    );
  }

  if (identifying) {
    return (
      <AppScreen title="Identifying...">
        <View style={styles.screenContainer}>
          <View style={styles.headerActions}>
            <AppIconButton
              name="close"
              onPress={handleCancel}
            />
          </View>
          <View style={styles.centerContent}>
            <ActivityIndicator size="large" color={colors.accent} />
            <AppText variant="body" style={{ marginTop: spacing.md, marginBottom: spacing.lg }}>
              Analyzing album cover...
            </AppText>
            <AppButton
              title="Cancel"
              variant="ghost"
              onPress={handleCancel}
            />
          </View>
        </View>
      </AppScreen>
    );
  }

  if (capturedUri && !result) {
    return (
      <AppScreen title="Processing...">
        <View style={styles.screenContainer}>
          <View style={styles.headerActions}>
            <AppIconButton
              name="close"
              onPress={handleCancel}
            />
          </View>
          <View style={styles.centerContent}>
            <Image
              source={{ uri: capturedUri }}
              style={[styles.previewImage, { borderRadius: radius.md }]}
            />
            <ActivityIndicator size="large" color={colors.accent} style={{ marginTop: spacing.md, marginBottom: spacing.lg }} />
            <AppButton
              title="Cancel"
              variant="ghost"
              onPress={handleCancel}
            />
          </View>
        </View>
      </AppScreen>
    );
  }

  return (
    <AppScreen title="Scan Record" scroll={false}>
      <View style={styles.screenContainer}>
        <View style={styles.headerActionsLeft}>
          <AppIconButton
            name="arrow-back"
            onPress={() => navigation.goBack()}
          />
        </View>
        {/* Scan Mode Toggle */}
        <View style={[styles.modeToggle, { marginBottom: spacing.md }]}>
          <TouchableOpacity
            style={[
              styles.modeButton,
              {
                backgroundColor: scanMode === 'image' ? colors.accent : colors.backgroundMuted,
                borderColor: colors.borderSubtle,
              },
            ]}
            onPress={() => setScanMode('image')}
          >
            <Ionicons 
              name="camera" 
              size={20} 
              color={scanMode === 'image' ? colors.background : colors.textSecondary} 
            />
            <AppText 
              variant="caption" 
              style={{ 
                color: scanMode === 'image' ? colors.background : colors.textSecondary,
                marginLeft: spacing.xs,
              }}
            >
              Image
            </AppText>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.modeButton,
              {
                backgroundColor: scanMode === 'barcode' ? colors.accent : colors.backgroundMuted,
                borderColor: colors.borderSubtle,
              },
            ]}
            onPress={() => setScanMode('barcode')}
          >
            <Ionicons 
              name="barcode" 
              size={20} 
              color={scanMode === 'barcode' ? colors.background : colors.textSecondary} 
            />
            <AppText 
              variant="caption" 
              style={{ 
                color: scanMode === 'barcode' ? colors.background : colors.textSecondary,
                marginLeft: spacing.xs,
              }}
            >
              Barcode
            </AppText>
          </TouchableOpacity>
        </View>

        <View style={styles.cameraContainer}>
        <CameraView
          ref={cameraRef}
          style={styles.camera}
          facing="back"
          barcodeScannerSettings={
            scanMode === 'barcode' ? {
              barcodeTypes: ['ean13', 'ean8', 'upc_a', 'upc_e', 'code128', 'code39'],
            } : undefined
          }
          onBarcodeScanned={
            scanMode === 'barcode'
              ? async (event) => {
                  if (identifying) return; // Prevent multiple scans
                  const barcode = event.data;
                  console.log(`[ScanRecord] Barcode scanned: ${barcode}`);
                  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                  
                  setIdentifying(true);
                  setScanning(false);
                  
                  try {
                    const response = await identifyRecordByBarcode(barcode);
                    // Normalize response into ScanResult structure
                    const normalizedResult = normalizeScanResult(response);
                    setResult(normalizedResult);
                  } catch (error: any) {
                    console.error('Barcode identification failed', error);
                    Alert.alert(
                      'Barcode Not Found',
                      `Could not find album for barcode "${barcode}". Try scanning the cover image instead.`,
                      [
                        { text: 'OK', onPress: () => setScanMode('image') },
                      ]
                    );
                  } finally {
                    setIdentifying(false);
                  }
                }
              : undefined
          }
          onCameraReady={() => {
            setScanning(true);
          }}
        >
          <View style={styles.overlay}>
            <View style={styles.scanFrame}>
              <Animated.View
                style={[
                  styles.scanLine,
                  {
                    backgroundColor: colors.accent,
                    transform: [{ translateY: scanLineTranslateY }],
                  },
                ]}
              />
            </View>
            <AppText variant="caption" style={styles.instruction}>
              {scanMode === 'barcode' 
                ? 'Position barcode in frame\nIt will scan automatically'
                : 'Position album cover in frame\nTap the button below to capture'}
            </AppText>
          </View>
        </CameraView>
        <View style={styles.cameraControls}>
          {capturing ? (
            <View style={styles.captureButton}>
              <ActivityIndicator size="small" color={colors.background} />
            </View>
          ) : (
            <TouchableOpacity
              style={[
                styles.captureButton,
                {
                  backgroundColor: colors.accent,
                },
              ]}
              onPress={handleManualCapture}
            >
              <Ionicons name="camera" size={32} color={colors.background} />
            </TouchableOpacity>
          )}
          <AppText variant="caption" style={{ marginTop: spacing.sm, color: colors.textMuted }}>
            Tap to capture and identify
          </AppText>
        </View>
      </View>
      </View>
    </AppScreen>
  );
};

const styles = StyleSheet.create({
  centerContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 48,
  },
  modeToggle: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  modeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
  },
  cameraContainer: {
    flex: 1,
  },
  camera: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanFrame: {
    width: 300,
    height: 300,
    borderWidth: 2,
    borderColor: '#08F7FE',
    borderRadius: 8,
    overflow: 'hidden',
    position: 'relative',
  },
  scanLine: {
    position: 'absolute',
    width: '100%',
    height: 2,
    opacity: 0.8,
  },
  instruction: {
    marginTop: 24,
    color: '#F8F8F8',
    textAlign: 'center',
  },
  cameraControls: {
    padding: 24,
    alignItems: 'center',
    backgroundColor: '#111113',
  },
  captureButton: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
  },
  previewImage: {
    width: 300,
    height: 300,
  },
  matchCover: {
    width: 200,
    height: 200,
    alignSelf: 'center',
  },
  divider: {
    height: 1,
    width: '100%',
  },
  alternateItem: {
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    marginBottom: 8,
  },
  actions: {
    flexDirection: 'row',
    marginTop: 24,
  },
  screenContainer: {
    flex: 1,
    position: 'relative',
  },
  headerActions: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 1000,
  },
  headerActionsLeft: {
    position: 'absolute',
    top: 16,
    left: 16,
    zIndex: 1000,
  },
});

