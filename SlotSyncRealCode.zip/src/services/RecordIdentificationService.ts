import * as FileSystem from 'expo-file-system/legacy';
import { getApiUrl, API_CONFIG } from '../config/api';
import { resizeImageForVision } from '../utils/imageResize';

export type TrackInfo = {
  title: string;
  trackNumber?: number;
  discNumber?: number | null;
  side?: string | null;
  durationSeconds?: number | null;
};

export type IdentificationMatch = {
  artist: string;
  title: string;
  year?: number;
  coverImageRemoteUrl?: string;
  discogsId?: string;
  tracks?: TrackInfo[];
  confidence?: number;
  source?: string;
};

export type IdentifiedAlbum = IdentificationMatch;

export type ScanResult = {
  current: IdentifiedAlbum;
  alternates: IdentifiedAlbum[];
};

export type IdentificationResponse = {
  confidence: number;
  bestMatch: IdentificationMatch;
  alternates: IdentificationMatch[];
  candidates?: IdentificationMatch[];
  primaryMatch?: IdentificationMatch;
};

export type IdentificationError = {
  code: 'NETWORK_ERROR' | 'INVALID_IMAGE' | 'API_ERROR' | 'TIMEOUT' | 'UNKNOWN' | 'LOW_CONFIDENCE';
  message: string;
  originalError?: unknown;
  candidates?: IdentificationMatch[];
  extractedText?: string;
};

/**
 * Frontend safety filter: Check if a candidate looks like a real album
 * Rejects URLs, article titles, Wikipedia pages, social media, etc.
 * This is a second-layer safety filter in addition to backend filtering.
 */
function looksLikeRealAlbumTitle(candidate: IdentificationMatch): boolean {
  if (!candidate.title || candidate.title.length < 2) return false;
  if (!candidate.artist) return false; // Must have artist

  const artist = (candidate.artist || '').trim().toLowerCase();
  const title = candidate.title.trim().toLowerCase();
  const combined = `${artist} ${title}`;

  // Reject URLs
  if (combined.includes('http://') || combined.includes('https://') || 
      combined.includes('www.') || combined.includes('.com') ||
      combined.includes('.net') || combined.includes('.org')) {
    return false;
  }

  // Reject article/blog patterns
  const badPatterns = [
    'wikipedia', 'wiki/', 'review', 'reviews', 'lyrics', 'lyric',
    'blog', 'reddit', 'facebook', 'twitter', 'pinterest', 'instagram',
    'best album covers', 'top ', 'the 10 best', 'the 20 best',
    'album covers from', 'r/musicsuggestions', 'r/', '| releases',
    'discogs', 'releases', 'release',
  ];
  
  if (badPatterns.some(p => combined.includes(p))) return false;

  // Reject pipe characters (common in web page titles)
  if (artist.includes('|') || title.includes('|')) return false;

  // Reject titles that are too long (likely sentences, not album names)
  if (title.length > 80) return false;

  // Reject generic words
  if (['discogs', 'releases', 'album', 'albums'].includes(title)) return false;

  return true;
}

/**
 * Retry configuration for API calls
 */
const RETRY_CONFIG = {
  maxRetries: 3,
  initialDelay: 1000, // 1 second
  maxDelay: 10000, // 10 seconds
  backoffMultiplier: 2,
};

/**
 * Calculates exponential backoff delay
 */
const getRetryDelay = (attempt: number): number => {
  const delay = RETRY_CONFIG.initialDelay * Math.pow(RETRY_CONFIG.backoffMultiplier, attempt);
  return Math.min(delay, RETRY_CONFIG.maxDelay);
};

/**
 * Identifies a vinyl record from a barcode
 * 
 * @param barcode - Barcode string (EAN, UPC, etc.)
 * @param abortSignal - Optional AbortSignal to cancel the request
 * @returns Promise with identification results including best match and alternates
 * @throws IdentificationError if identification fails
 */
export const identifyRecordByBarcode = async (
  barcode: string,
  abortSignal?: AbortSignal
): Promise<IdentificationResponse> => {
  // Retry logic with exponential backoff
  let lastError: IdentificationError | null = null;
  
  for (let attempt = 0; attempt <= RETRY_CONFIG.maxRetries; attempt++) {
    if (attempt > 0) {
      const delay = getRetryDelay(attempt - 1);
      console.log(`[RecordIdentification] Barcode retry attempt ${attempt}/${RETRY_CONFIG.maxRetries} after ${delay}ms...`);
      
      if (abortSignal?.aborted) {
        throw {
          code: 'UNKNOWN' as const,
          message: 'Request cancelled',
        } as IdentificationError;
      }
      
      await new Promise(resolve => setTimeout(resolve, delay));
    }

    let timeoutId: NodeJS.Timeout | null = null;
    
    try {
      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

      if (abortSignal) {
        abortSignal.addEventListener('abort', () => controller.abort());
      }

      const apiUrl = getApiUrl(API_CONFIG.ENDPOINTS.IDENTIFY_RECORD);
      
      // CRITICAL: Log the exact URL being called
      console.log(`[RecordIdentification] ========================================`);
      console.log(`[RecordIdentification] 🚀 CALLING API WITH BARCODE (attempt ${attempt + 1})`);
      console.log(`[RecordIdentification] 📍 Full URL: ${apiUrl}`);
      console.log(`[RecordIdentification] 📍 Base URL: ${API_CONFIG.BASE_URL}`);
      console.log(`[RecordIdentification] 📍 Barcode: ${barcode}`);
      console.log(`[RecordIdentification] ⏱️  Timeout: ${API_CONFIG.TIMEOUT}ms (90 seconds)`);
      
      // Validate URL doesn't contain localhost (won't work on physical devices)
      if (apiUrl.includes('localhost') || apiUrl.includes('127.0.0.1')) {
        console.error(`[RecordIdentification] ❌ ERROR: URL contains localhost/127.0.0.1!`);
        console.error(`[RecordIdentification] ❌ This will NOT work on physical devices!`);
        console.error(`[RecordIdentification] ❌ Set EXPO_PUBLIC_API_BASE_URL to your computer's LAN IP`);
        throw {
          code: 'NETWORK_ERROR' as const,
          message: 'API URL contains localhost. Physical devices cannot reach localhost. Set EXPO_PUBLIC_API_BASE_URL to your computer\'s LAN IP address (e.g., http://192.168.1.100:3000)',
        } as IdentificationError;
      }
      
      console.log(`[RecordIdentification] ========================================`);

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ barcode }),
        signal: controller.signal,
      });

      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }

      if (!response.ok) {
        let errorData: any = {};
        try {
          const errorText = await response.text();
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { message: await response.text().catch(() => 'Unknown error') };
        }

        if (response.status === 400) {
          throw {
            code: 'API_ERROR' as const,
            message: `Barcode not found: ${errorData.message || errorData.error || 'Unknown error'}`,
            originalError: errorData,
          } as IdentificationError;
        }

        if (response.status >= 500 && attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'API_ERROR' as const,
            message: `API returned ${response.status}: ${errorData.message || errorData.error || 'Server error'}`,
            originalError: errorData,
          } as IdentificationError;
          continue;
        }

        throw {
          code: 'API_ERROR' as const,
          message: `API returned ${response.status}: ${errorData.message || errorData.error || 'Unknown error'}`,
          originalError: errorData,
        } as IdentificationError;
      }

      const data = await response.json();

      if (!data.bestMatch || !data.bestMatch.artist || !data.bestMatch.title) {
        throw {
          code: 'API_ERROR' as const,
          message: 'Invalid response format from API',
        } as IdentificationError;
      }

      console.log(`[RecordIdentification] ✅ Barcode success on attempt ${attempt + 1}`);
      return data as IdentificationResponse;
    } catch (error: any) {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }

      if (error.name === 'AbortError' || abortSignal?.aborted) {
        if (abortSignal?.aborted) {
          throw {
            code: 'UNKNOWN' as const,
            message: 'Request cancelled',
            originalError: error,
          } as IdentificationError;
        }
        
        if (attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'TIMEOUT' as const,
            message: 'Request timed out. Retrying...',
            originalError: error,
          } as IdentificationError;
          continue;
        }
        
        throw {
          code: 'TIMEOUT' as const,
          message: 'Request timed out after multiple attempts.',
          originalError: error,
        } as IdentificationError;
      }

      if (error.message?.includes('Network request failed') || error.message?.includes('Failed to fetch')) {
        if (attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'NETWORK_ERROR' as const,
            message: 'Network error. Retrying...',
            originalError: error,
          } as IdentificationError;
          continue;
        }
        
        throw {
          code: 'NETWORK_ERROR' as const,
          message: 'Network error after multiple attempts.',
          originalError: error,
        } as IdentificationError;
      }

      if (error.code && error.message) {
        if (error.code === 'INVALID_IMAGE') {
          throw error as IdentificationError;
        }
        
        if (attempt < RETRY_CONFIG.maxRetries && error.code !== 'API_ERROR') {
          lastError = error as IdentificationError;
          continue;
        }
        
        throw error as IdentificationError;
      }

      if (attempt < RETRY_CONFIG.maxRetries) {
        lastError = {
          code: 'UNKNOWN' as const,
          message: error.message || 'An unexpected error occurred. Retrying...',
          originalError: error,
        } as IdentificationError;
        continue;
      }

      throw {
        code: 'UNKNOWN' as const,
        message: error.message || 'An unexpected error occurred after multiple attempts',
        originalError: error,
      } as IdentificationError;
    }
  }

  if (lastError) {
    throw lastError;
  }

  throw {
    code: 'UNKNOWN' as const,
    message: 'Barcode identification failed after all retry attempts',
  } as IdentificationError;
};

/**
 * Test connectivity to the backend API
 * This should be called before attempting identification
 */
export const testApiConnectivity = async (): Promise<boolean> => {
  try {
    const pingUrl = getApiUrl(API_CONFIG.ENDPOINTS.PING || '/api/ping');
    console.log(`[RecordIdentification] 🔍 Testing connectivity to: ${pingUrl}`);
    console.log(`[RecordIdentification] 🔍 Base URL: ${API_CONFIG.BASE_URL}`);
    
    // Use AbortController for timeout (AbortSignal.timeout is not available in React Native)
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout for ping
    
    const response = await fetch(pingUrl, {
      method: 'GET',
      signal: controller.signal,
    });
    
    clearTimeout(timeoutId);
    
    if (response.ok) {
      const data = await response.json();
      console.log(`[RecordIdentification] ✅ Connectivity test passed:`, data);
      return true;
    } else {
      console.warn(`[RecordIdentification] ⚠️  Connectivity test failed: HTTP ${response.status}`);
      return false;
    }
  } catch (error: any) {
    // Clear timeout if it was set
    if (error.name === 'AbortError') {
      console.error(`[RecordIdentification] ❌ Connectivity test timed out after 5 seconds`);
    } else {
      console.error(`[RecordIdentification] ❌ Connectivity test failed:`, error.message);
    }
    console.error(`[RecordIdentification] ❌ This usually means the backend is unreachable at ${API_CONFIG.BASE_URL}`);
    console.error(`[RecordIdentification] ❌ Check that:`);
    console.error(`[RecordIdentification]    1. Backend server is running (node server-hybrid.js)`);
    console.error(`[RecordIdentification]    2. EXPO_PUBLIC_API_BASE_URL is set correctly`);
    console.error(`[RecordIdentification]    3. Device and computer are on the same Wi-Fi network`);
    return false;
  }
};

export const identifyRecord = async (
  imageUri: string,
  abortSignal?: AbortSignal
): Promise<IdentificationResponse> => {
  // Test connectivity first (only log, don't fail)
  try {
    await testApiConnectivity();
  } catch (err) {
    console.warn('[RecordIdentification] Connectivity test failed, but continuing...');
  }

  // Validate image file exists
  const fileInfo = await FileSystem.getInfoAsync(imageUri);
  if (!fileInfo.exists) {
    throw {
      code: 'INVALID_IMAGE' as const,
      message: 'Image file not found',
    } as IdentificationError;
  }

  // CRITICAL: Image should already be JPEG (converted by capture/selection handlers)
  // Image is already resized to 1200px by convertToJpeg, so we use a larger size here
  // for better OCR accuracy. Google Vision works well up to ~1024px on long side.
  // We'll use 1024px max to balance quality vs. upload speed.
  console.log('[RecordIdentification] Preparing image for Vision API...');
  console.log('[RecordIdentification] Input image URI:', imageUri);
  
  // Get image info first to log dimensions
  try {
    const imageInfo = await FileSystem.getInfoAsync(imageUri);
    if (imageInfo.exists && 'size' in imageInfo) {
      const sizeKB = (imageInfo.size || 0) / 1024;
      console.log(`[RecordIdentification] Image size: ${sizeKB.toFixed(2)}KB`);
    }
  } catch (err) {
    // Ignore - just logging
  }
  
  // Resize to optimal size for Vision API (1024px max width, maintains aspect ratio)
  // This is larger than 640x480 for better OCR accuracy while staying under 10MB limit
  const resizedImageUri = await resizeImageForVision(imageUri, {
    maxWidth: 1024, // Increased from 640 for better OCR accuracy
    maxHeight: 1024, // Increased from 480 for better OCR accuracy
    quality: 0.85, // 85% quality - good balance
  });
  console.log('[RecordIdentification] ✅ Image prepared for Vision API, using:', resizedImageUri);

  // Retry logic with exponential backoff
  let lastError: IdentificationError | null = null;
  
  for (let attempt = 0; attempt <= RETRY_CONFIG.maxRetries; attempt++) {
    if (attempt > 0) {
      const delay = getRetryDelay(attempt - 1);
      console.log(`[RecordIdentification] Retry attempt ${attempt}/${RETRY_CONFIG.maxRetries} after ${delay}ms...`);
      
      // Check if request was aborted before retrying
      if (abortSignal?.aborted) {
        throw {
          code: 'UNKNOWN' as const,
          message: 'Request cancelled',
        } as IdentificationError;
      }
      
      await new Promise(resolve => setTimeout(resolve, delay));
    }

    // Declare timeoutId outside try block for catch access
    let timeoutId: NodeJS.Timeout | null = null;
    
    try {
      // Create FormData for multipart upload
      // React Native FormData format
      const formData = new FormData();
      formData.append('image', {
        uri: resizedImageUri, // Use resized image
        type: 'image/jpeg',
        name: 'cover.jpg',
      } as any);

      // Create AbortController for timeout
      const controller = new AbortController();
      timeoutId = setTimeout(() => controller.abort(), API_CONFIG.TIMEOUT);

      // Merge abort signals if provided
      if (abortSignal) {
        abortSignal.addEventListener('abort', () => controller.abort());
      }

      const apiUrl = getApiUrl(API_CONFIG.ENDPOINTS.IDENTIFY_RECORD);
      
      // CRITICAL: Log the exact URL being called
      console.log(`[RecordIdentification] ========================================`);
      console.log(`[RecordIdentification] 🚀 CALLING API (attempt ${attempt + 1})`);
      console.log(`[RecordIdentification] 📍 Full URL: ${apiUrl}`);
      console.log(`[RecordIdentification] 📍 Base URL: ${API_CONFIG.BASE_URL}`);
      console.log(`[RecordIdentification] 📍 Endpoint: ${API_CONFIG.ENDPOINTS.IDENTIFY_RECORD}`);
      console.log(`[RecordIdentification] ⏱️  Timeout: ${API_CONFIG.TIMEOUT}ms (90 seconds)`);
      
      // Validate URL doesn't contain localhost (won't work on physical devices)
      if (apiUrl.includes('localhost') || apiUrl.includes('127.0.0.1')) {
        console.error(`[RecordIdentification] ❌ ERROR: URL contains localhost/127.0.0.1!`);
        console.error(`[RecordIdentification] ❌ This will NOT work on physical devices!`);
        console.error(`[RecordIdentification] ❌ Set EXPO_PUBLIC_API_BASE_URL to your computer's LAN IP`);
        throw {
          code: 'NETWORK_ERROR' as const,
          message: 'API URL contains localhost. Physical devices cannot reach localhost. Set EXPO_PUBLIC_API_BASE_URL to your computer\'s LAN IP address (e.g., http://192.168.1.100:3000)',
        } as IdentificationError;
      }
      
      console.log(`[RecordIdentification] ========================================`);

      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData,
        signal: controller.signal,
        // Don't set Content-Type header - let fetch set it with boundary
        headers: {},
      });

      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }

      if (!response.ok) {
        let errorData: any = {};
        try {
          const errorText = await response.text();
          errorData = JSON.parse(errorText);
        } catch {
          // If parsing fails, use the raw text
          errorData = { message: await response.text().catch(() => 'Unknown error') };
        }

        // Check if this is a low confidence error with candidates or suggestions
        if (response.status === 400) {
          // If backend explicitly set code: 'LOW_CONFIDENCE', use that
          if (errorData.code === 'LOW_CONFIDENCE') {
            // Prefer candidates from backend (already filtered and clean)
            // Apply frontend safety filter as second layer
            const candidates: IdentificationMatch[] = (Array.isArray(errorData.candidates) ? errorData.candidates : [])
              .filter((c: any) => c.artist && c.title)
              .map((c: any) => ({
                artist: c.artist,
                title: c.title,
                year: c.year || undefined,
                confidence: c.confidence || undefined,
                source: c.source || undefined,
                coverImageRemoteUrl: c.coverImageRemoteUrl || undefined,
                discogsId: c.discogsId || undefined,
              }))
              .filter(looksLikeRealAlbumTitle); // Frontend safety filter

            console.log(`[RecordIdentification] Low confidence error with ${candidates.length} candidates, extractedText: ${errorData.extractedText ? 'yes' : 'no'}`);
            throw {
              code: 'LOW_CONFIDENCE' as const,
              message: errorData.message || errorData.error || 'Low confidence match. Please review suggestions.',
              candidates: candidates.length > 0 ? candidates : undefined,
              extractedText: errorData.extractedText || undefined,
            } as IdentificationError;
          }
          
          // Fallback: Check for candidates/suggestions even if code not explicitly set
          // Prefer discogsSuggestions if available (they have similarity scores)
          const suggestionSource = errorData.discogsSuggestions && errorData.discogsSuggestions.length > 0
            ? errorData.discogsSuggestions
            : errorData.candidates;
          
          // Convert candidates/suggestions to IdentificationMatch format
          // Apply frontend safety filter as second layer
          const candidates: IdentificationMatch[] = (Array.isArray(suggestionSource) ? suggestionSource : [])
            .filter((c: any) => c.artist && c.title)
            .map((c: any) => ({
              artist: c.artist,
              title: c.title,
              year: c.year || undefined,
              coverImageRemoteUrl: c.coverImageRemoteUrl || undefined,
              discogsId: c.discogsId || undefined,
            }))
            .filter(looksLikeRealAlbumTitle); // Frontend safety filter

          // If we have candidates OR extracted text, treat as LOW_CONFIDENCE (not complete failure)
          // Don't retry for low confidence - return immediately
          if (candidates.length > 0 || errorData.extractedText) {
            console.log(`[RecordIdentification] Low confidence error with ${candidates.length} candidates, extractedText: ${errorData.extractedText ? 'yes' : 'no'}`);
            throw {
              code: 'LOW_CONFIDENCE' as const,
              message: errorData.message || errorData.error || 'Low confidence match. Please review suggestions.',
              candidates: candidates.length > 0 ? candidates : undefined,
              extractedText: errorData.extractedText || undefined,
            } as IdentificationError;
          }
        }

        // For 400 errors without candidates, don't retry
        if (response.status === 400) {
          throw {
            code: 'API_ERROR' as const,
            message: `API returned ${response.status}: ${errorData.message || errorData.error || 'Unknown error'}`,
            originalError: errorData,
          } as IdentificationError;
        }

        // For 5xx errors, retry
        if (response.status >= 500 && attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'API_ERROR' as const,
            message: `API returned ${response.status}: ${errorData.message || errorData.error || 'Server error'}`,
            originalError: errorData,
          } as IdentificationError;
          continue; // Retry
        }

        // For other errors, don't retry
        throw {
          code: 'API_ERROR' as const,
          message: `API returned ${response.status}: ${errorData.message || errorData.error || 'Unknown error'}`,
          originalError: errorData,
        } as IdentificationError;
      }

      const data = await response.json();

      // Validate response structure
      if (!data.bestMatch || !data.bestMatch.artist || !data.bestMatch.title) {
        throw {
          code: 'API_ERROR' as const,
          message: 'Invalid response format from API',
        } as IdentificationError;
      }

      console.log(`[RecordIdentification] ✅ Success on attempt ${attempt + 1}`);
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }
      return data as IdentificationResponse;
    } catch (error: any) {
      if (timeoutId) {
        clearTimeout(timeoutId);
        timeoutId = null;
      }

      // Handle abort (timeout or user cancellation)
      if (error.name === 'AbortError' || abortSignal?.aborted) {
        // Don't throw error if user cancelled - just let it fail silently
        if (abortSignal?.aborted) {
          throw {
            code: 'UNKNOWN' as const,
            message: 'Request cancelled',
            originalError: error,
          } as IdentificationError;
        }
        
        // Timeout - retry if we have attempts left
        if (attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'TIMEOUT' as const,
            message: 'Request timed out. Retrying...',
            originalError: error,
          } as IdentificationError;
          continue; // Retry
        }
        
        throw {
          code: 'TIMEOUT' as const,
          message: 'Request timed out after multiple attempts. Please check your connection and try again.',
          originalError: error,
        } as IdentificationError;
      }

      // Handle network errors - retry if we have attempts left
      if (error.message?.includes('Network request failed') || error.message?.includes('Failed to fetch')) {
        if (attempt < RETRY_CONFIG.maxRetries) {
          lastError = {
            code: 'NETWORK_ERROR' as const,
            message: 'Network error. Retrying...',
            originalError: error,
          } as IdentificationError;
          continue; // Retry
        }
        
        throw {
          code: 'NETWORK_ERROR' as const,
          message: 'Network error after multiple attempts. Please check your internet connection and API configuration.',
          originalError: error,
        } as IdentificationError;
      }

      // If it's already an IdentificationError, check if we should retry
      if (error.code && error.message) {
        // Don't retry for LOW_CONFIDENCE or INVALID_IMAGE
        if (error.code === 'LOW_CONFIDENCE' || error.code === 'INVALID_IMAGE') {
          throw error as IdentificationError;
        }
        
        // For other errors, retry if we have attempts left
        if (attempt < RETRY_CONFIG.maxRetries && error.code !== 'API_ERROR') {
          lastError = error as IdentificationError;
          continue; // Retry
        }
        
        throw error as IdentificationError;
      }

      // Unknown error - retry if we have attempts left
      if (attempt < RETRY_CONFIG.maxRetries) {
        lastError = {
          code: 'UNKNOWN' as const,
          message: error.message || 'An unexpected error occurred. Retrying...',
          originalError: error,
        } as IdentificationError;
        continue; // Retry
      }

      // Final attempt failed
      throw {
        code: 'UNKNOWN' as const,
        message: error.message || 'An unexpected error occurred after multiple attempts',
        originalError: error,
      } as IdentificationError;
    }
  }

  // All retries exhausted
  if (lastError) {
    throw lastError;
  }

  throw {
    code: 'UNKNOWN' as const,
    message: 'Identification failed after all retry attempts',
  } as IdentificationError;
};

/**
 * Normalizes an IdentificationResponse into a ScanResult structure
 * Combines primaryMatch/bestMatch with candidates to create current + alternates
 */
export const normalizeScanResult = (response: IdentificationResponse): ScanResult => {
  // Get primary match (could be primaryMatch or bestMatch)
  const primary = response.primaryMatch || response.bestMatch;
  
  // Get all candidates (could be from candidates array or alternates)
  const allCandidates: IdentifiedAlbum[] = response.candidates || response.alternates || [];
  
  // Combine primary with candidates, ensuring primary is first
  const normalized = [primary, ...allCandidates]
    .filter(Boolean)
    .filter((item, index, arr) =>
      index === arr.findIndex(x => x.artist === item.artist && x.title === item.title)
    )
    .map(item => ({
      ...item,
      confidence: item.confidence ?? response.confidence,
    }))
    .sort((a, b) => (b.confidence ?? 0) - (a.confidence ?? 0));
  
  // Split into current and alternates (max 2 alternates)
  const [current, ...rest] = normalized;
  
  return {
    current: current || primary, // Fallback to primary if somehow empty
    alternates: rest.slice(0, 2), // At most 2 alternates
  };
};

