/**
 * Vision Result Extractor
 * 
 * Extracts artist and title from Google Vision API results using multiple strategies.
 * Prioritizes web detection over OCR for better accuracy.
 */

/**
 * Extract artist and title from Vision API results
 * 
 * Strategy priority:
 * 1. Web detection page titles (most reliable)
 * 2. Web entities descriptions
 * 3. OCR text with heuristics
 * 
 * @param {Object} visionResult - Vision API response object
 * @returns {Object|null} { artist, title, source } or null if extraction fails
 */
function extractArtistTitleFromVision(visionResult) {
  if (!visionResult) {
    return null;
  }

  const DEBUG = process.env.DEBUG_IDENTIFICATION === 'true';
  
  // Strategy 1: Web Detection Page Titles (highest priority)
  if (visionResult.pageTitles && visionResult.pageTitles.length > 0) {
    for (const page of visionResult.pageTitles) {
      const pageTitle = page.pageTitle || '';
      if (!pageTitle || pageTitle.trim().length < 5) continue;
      
      const extracted = extractFromText(pageTitle, 'web_page_title');
      if (extracted) {
        if (DEBUG) {
          console.log(`[VisionExtractor] ✅ Extracted from page title: "${extracted.artist}" - "${extracted.title}"`);
        }
        return extracted;
      }
    }
  }

  // Strategy 2: Web Entities Descriptions
  if (visionResult.webEntities && visionResult.webEntities.length > 0) {
    // Sort by score (highest first)
    const sortedEntities = [...visionResult.webEntities].sort((a, b) => (b.score || 0) - (a.score || 0));
    
    for (const entity of sortedEntities.slice(0, 10)) {
      const description = entity.description || '';
      if (!description || description.trim().length < 5) continue;
      if ((entity.score || 0) < 0.3) continue; // Skip low-confidence entities
      
      const extracted = extractFromText(description, 'web_entity');
      if (extracted) {
        if (DEBUG) {
          console.log(`[VisionExtractor] ✅ Extracted from web entity (score: ${entity.score}): "${extracted.artist}" - "${extracted.title}"`);
        }
        return extracted;
      }
    }
  }

  // Strategy 3: OCR Full Text (last resort)
  if (visionResult.extractedText && visionResult.extractedText.trim().length > 0) {
    const extracted = extractFromText(visionResult.extractedText, 'ocr');
    if (extracted) {
      if (DEBUG) {
        console.log(`[VisionExtractor] ✅ Extracted from OCR: "${extracted.artist}" - "${extracted.title}"`);
      }
      return extracted;
    }
  }

  if (DEBUG) {
    console.log('[VisionExtractor] ❌ Failed to extract artist/title from any source');
  }
  return null;
}

/**
 * Extract artist and title from text using multiple heuristics
 * 
 * @param {string} text - Text to extract from
 * @param {string} source - Source identifier for logging
 * @returns {Object|null} { artist, title, source } or null
 */
function extractFromText(text, source) {
  if (!text || typeof text !== 'string' || text.trim().length < 5) {
    return null;
  }

  const normalized = normalizeText(text);
  if (normalized.length < 5) return null;

  // Heuristic 1: Dash/separator patterns ("Artist - Title")
  const dashPatterns = [
    { regex: /^(.+?)\s*[-–—]\s*(.+)$/, reverse: false },
    { regex: /^(.+?)\s*:\s*(.+)$/, reverse: false },
    { regex: /^(.+?)\s+by\s+(.+)$/i, reverse: true },
    { regex: /^(.+?)\s*\/\s*(.+)$/, reverse: false },
    { regex: /^(.+?)\s*\|\s*(.+)$/, reverse: false },
  ];

  for (const { regex, reverse } of dashPatterns) {
    const match = normalized.match(regex);
    if (match) {
      const part1 = match[1].trim();
      const part2 = match[2].trim();
      
      if (isValidPart(part1) && isValidPart(part2)) {
        return {
          artist: reverse ? part2 : part1,
          title: reverse ? part1 : part2,
          source: `${source}_dash`,
        };
      }
    }
  }

  // Heuristic 2: Line-based extraction (first two non-empty lines)
  const lines = normalized.split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);
  
  if (lines.length >= 2) {
    const line1 = lines[0];
    const line2 = lines[1];
    
    if (isValidPart(line1) && isValidPart(line2)) {
      // Common pattern: artist on first line, title on second
      return {
        artist: line1,
        title: line2,
        source: `${source}_lines`,
      };
    }
  }

  // Heuristic 3: Single line with word count heuristic
  if (lines.length === 1 || normalized.split(/\s+/).length >= 3) {
    const words = normalized.split(/\s+/).filter(w => w.length > 0);
    
    if (words.length >= 3 && words.length <= 10) {
      // Try splitting at different points
      for (let splitPoint = 2; splitPoint <= Math.min(4, words.length - 1); splitPoint++) {
        const artistPart = words.slice(0, splitPoint).join(' ');
        const titlePart = words.slice(splitPoint).join(' ');
        
        if (isValidPart(artistPart) && isValidPart(titlePart)) {
          return {
            artist: artistPart,
            title: titlePart,
            source: `${source}_word_split`,
          };
        }
      }
    }
  }

  return null;
}

/**
 * Normalize text for extraction
 */
function normalizeText(text) {
  if (!text || typeof text !== 'string') return '';
  
  return text
    .trim()
    // Normalize whitespace
    .replace(/\s+/g, ' ')
    // Remove leading/trailing punctuation
    .replace(/^[^\w\s]+|[^\w\s]+$/g, '')
    .trim();
}

/**
 * Validate that a part (artist or title) is reasonable
 */
function isValidPart(part) {
  if (!part || typeof part !== 'string') return false;
  const trimmed = part.trim();
  
  // Length checks
  if (trimmed.length < 2 || trimmed.length > 100) return false;
  
  // Filter out common false positives
  const falsePositives = ['album', 'vinyl', 'record', 'lp', 'cd', 'the', 'a', 'an', 'by'];
  const lower = trimmed.toLowerCase();
  if (falsePositives.includes(lower)) return false;
  
  // Must have at least one letter
  if (!/[a-zA-Z]/.test(trimmed)) return false;
  
  return true;
}

module.exports = {
  extractArtistTitleFromVision,
};

