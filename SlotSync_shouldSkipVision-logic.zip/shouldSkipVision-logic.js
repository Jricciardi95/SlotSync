/**
 * Phase 2A: Skip Vision API Logic
 * 
 * This file contains the extracted logic for deciding whether to skip Vision API
 * when embedding similarity is high. This is part of the performance optimization
 * to reduce API calls and latency for high-confidence matches.
 * 
 * Location in server-hybrid.js: generateCandidatesFromInput() function
 * Lines: ~2085-2160
 */

// ============================================================================
// CONFIGURATION CONSTANTS
// ============================================================================

// Phase 2: Performance optimization thresholds
// Skip Vision API if embedding similarity is already very high (reduces API calls and latency)
const SKIP_VISION_EMBEDDING_THRESHOLD = parseFloat(process.env.SKIP_VISION_EMBEDDING_THRESHOLD || '0.92');
// Margin check: only skip if top1 - top2 >= margin (reduces wrong confident matches)
// Set to 0 to disable margin check
const SKIP_VISION_MARGIN_THRESHOLD = parseFloat(process.env.SKIP_VISION_MARGIN_THRESHOLD || '0.03');

// ============================================================================
// SKIP VISION DECISION LOGIC
// ============================================================================

/**
 * Determines whether to skip Vision API based on embedding similarity results.
 * 
 * Guardrails:
 * 1. Valid ID Check: Only skip if top match has valid discogsId/recordId (real match, not noise)
 * 2. Margin Check: Only skip if top1 - top2 >= margin threshold (reduces wrong confident matches)
 * 3. Similarity Threshold: Only skip if top1 >= SKIP_VISION_EMBEDDING_THRESHOLD
 * 
 * @param {Array} embeddingMatches - Array of embedding match results from findNearestCovers()
 * @param {Object} debugInfo - Debug info object to populate with decision details
 * @returns {Object} - { shouldSkipVision: boolean, topEmbeddingSimilarity: number, top1Id: string|null, top2Similarity: number|null }
 */
function shouldSkipVisionDecision(embeddingMatches, debugInfo) {
  // Initialize return values
  let topEmbeddingSimilarity = 0;
  let top1Id = null;
  let top2Similarity = null;
  let shouldSkipVision = false;

  // Only proceed if we have matches
  if (embeddingMatches.length === 0) {
    return { shouldSkipVision: false, topEmbeddingSimilarity: 0, top1Id: null, top2Similarity: null };
  }

  const topMatch = embeddingMatches[0];
  topEmbeddingSimilarity = topMatch.similarity;
  top1Id = topMatch.discogsId || topMatch.recordId || topMatch.metadata?.discogsId || topMatch.metadata?.recordId || null;

  // Get top2 similarity for margin check (if available)
  if (embeddingMatches.length > 1) {
    top2Similarity = embeddingMatches[1].similarity;
  }

  // Guardrail 1: Only skip if top match has valid discogsId/recordId (real match, not noise)
  const hasValidId = !!(topMatch.discogsId || topMatch.recordId || topMatch.metadata?.discogsId || topMatch.metadata?.recordId);

  // Guardrail 2: Margin check (top1 - top2 >= margin threshold, if margin check enabled)
  const marginCheck = SKIP_VISION_MARGIN_THRESHOLD <= 0 || top2Similarity === null ||
    (topEmbeddingSimilarity - top2Similarity) >= SKIP_VISION_MARGIN_THRESHOLD;

  // Guardrail 3: Similarity threshold check
  const similarityCheck = topEmbeddingSimilarity >= SKIP_VISION_EMBEDDING_THRESHOLD;

  // Decision: Skip Vision only if all guardrails pass
  if (similarityCheck && hasValidId && marginCheck) {
    shouldSkipVision = true;
    const marginStr = top2Similarity !== null
      ? ` (margin: ${(topEmbeddingSimilarity - top2Similarity).toFixed(3)})`
      : ' (margin: N/A)';
    console.log(`[Phase1] ⚡ SKIP VISION: High embedding similarity (${topEmbeddingSimilarity.toFixed(3)} >= ${SKIP_VISION_EMBEDDING_THRESHOLD}, top1Id: ${top1Id || 'N/A'}${marginStr})`);
    debugInfo.visionSkipped = true;
    debugInfo.visionSkipReason = `high_embedding_similarity_${topEmbeddingSimilarity.toFixed(3)}`;
    debugInfo.visionSkipTop1Id = top1Id;
    debugInfo.visionSkipTop1Similarity = topEmbeddingSimilarity;
    debugInfo.visionSkipTop2Similarity = top2Similarity;
    debugInfo.visionSkipMargin = top2Similarity !== null ? (topEmbeddingSimilarity - top2Similarity) : null;
  } else {
    const reasons = [];
    if (!similarityCheck) reasons.push(`similarity ${topEmbeddingSimilarity.toFixed(3)} < ${SKIP_VISION_EMBEDDING_THRESHOLD}`);
    if (!hasValidId) reasons.push('no valid ID');
    if (!marginCheck && SKIP_VISION_MARGIN_THRESHOLD > 0) {
      const margin = top2Similarity !== null ? (topEmbeddingSimilarity - top2Similarity).toFixed(3) : 'N/A';
      reasons.push(`margin ${margin} < ${SKIP_VISION_MARGIN_THRESHOLD}`);
    }
    console.log(`[Phase1] 🔍 RUN VISION: ${reasons.join(', ')} (top1Id: ${top1Id || 'N/A'}, top1: ${topEmbeddingSimilarity.toFixed(3)}, top2: ${top2Similarity !== null ? top2Similarity.toFixed(3) : 'N/A'})`);
    debugInfo.visionSkipped = false;
    debugInfo.visionSkipReasons = reasons;
  }

  return {
    shouldSkipVision,
    topEmbeddingSimilarity,
    top1Id,
    top2Similarity
  };
}

// ============================================================================
// USAGE EXAMPLE (from server-hybrid.js)
// ============================================================================

/*
// In generateCandidatesFromInput() function:

// STEP 2: Vector search for similar covers (core signal, not just add-on)
let topEmbeddingSimilarity = 0;
let top1Id = null;
let top2Similarity = null;
let shouldSkipVision = false;

if (queryEmbedding) {
  try {
    const EMBEDDING_K = parseInt(process.env.EMBEDDING_K || '5');
    const EMBEDDING_MIN_SIMILARITY = parseFloat(process.env.EMBEDDING_MIN_SIMILARITY || '0.65');
    
    const embeddingMatches = await findNearestCovers(queryEmbedding, EMBEDDING_K, EMBEDDING_MIN_SIMILARITY, db);
    debugInfo.embeddingMatches = embeddingMatches;
    debugInfo.embeddingNeighborsCount = embeddingMatches.length;
    
    // Phase 2A: Check if top embedding match is strong enough to skip Vision API
    if (embeddingMatches.length > 0) {
      const decision = shouldSkipVisionDecision(embeddingMatches, debugInfo);
      shouldSkipVision = decision.shouldSkipVision;
      topEmbeddingSimilarity = decision.topEmbeddingSimilarity;
      top1Id = decision.top1Id;
      top2Similarity = decision.top2Similarity;
      
      console.log(`[Phase1] 🔍 Found ${embeddingMatches.length} embedding neighbors (min similarity: ${EMBEDDING_MIN_SIMILARITY}, top: ${topEmbeddingSimilarity.toFixed(3)})`);
      
      // ... rest of candidate processing ...
    }
  } catch (embeddingError) {
    console.warn(`[Phase1] ⚠️  Vector search failed: ${embeddingError.message}`);
    debugInfo.embeddingSearchError = embeddingError.message;
  }
}

// STEP 3: Conditionally run Vision API (skip if embedding similarity is high)
let visionResult = null;
const ENABLE_GOOGLE_VISION = process.env.ENABLE_GOOGLE_VISION !== 'false';

if (!shouldSkipVision && ENABLE_GOOGLE_VISION && visionClient) {
  try {
    console.log(`[Phase1] 🔍 Starting Google Vision analysis (OCR-first approach)...`);
    const visionPromise = processImageWithGoogleVision(imageBuffer);
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Vision API timeout after 30 seconds')), 30000);
    });
    visionResult = await Promise.race([visionPromise, timeoutPromise]);
  } catch (err) {
    console.warn(`[Phase1] ⚠️  Vision API failed: ${err.message}`);
    debugInfo.visionError = err.message;
    visionResult = null;
  }
} else if (shouldSkipVision) {
  console.log(`[Phase1] ⏭️  Vision API skipped (high embedding match)`);
  debugInfo.visionSkipped = true;
} else if (!ENABLE_GOOGLE_VISION || !visionClient) {
  console.log(`[Phase1] ⏭️  Vision API disabled or not configured`);
  debugInfo.visionSkipped = true;
  debugInfo.visionSkipReason = 'vision_disabled';
}
*/

// ============================================================================
// ENHANCED LOGGING (from server-hybrid.js endpoint)
// ============================================================================

/*
// In /api/identify-record endpoint, after successful identification:

// Phase 2A: Enhanced logging for skip-Vision decision analysis
const phase2ALog = {
  timestamp: new Date().toISOString(),
  topEmbeddingSimilarity: debugInfo.visionSkipTop1Similarity || debugInfo.embeddingMatches?.[0]?.similarity || null,
  top1Id: debugInfo.visionSkipTop1Id || debugInfo.embeddingMatches?.[0]?.discogsId || debugInfo.embeddingMatches?.[0]?.recordId || null,
  top2Similarity: debugInfo.visionSkipTop2Similarity || (debugInfo.embeddingMatches?.length > 1 ? debugInfo.embeddingMatches[1].similarity : null),
  decision: debugInfo.visionSkipped ? 'SKIP' : 'RUN',
  margin: debugInfo.visionSkipMargin || (debugInfo.embeddingMatches?.length > 1 ? (debugInfo.embeddingMatches[0].similarity - debugInfo.embeddingMatches[1].similarity) : null),
  totalLatencyMs: debugInfo.processingTime,
  finalDiscogsId: primaryMatch.discogsId || null,
  finalMatch: `${primaryMatch.artist} - ${primaryMatch.title}`,
  confidence: primaryMatch.confidence,
  skipReasons: debugInfo.visionSkipReasons || null,
};
console.log(`[Phase2A] 📊 Decision log: ${JSON.stringify(phase2ALog)}`);
*/

// ============================================================================
// CONFIGURATION
// ============================================================================

/**
 * Environment Variables:
 * 
 * SKIP_VISION_EMBEDDING_THRESHOLD (default: 0.92)
 *   - Range: 0.90-0.93 recommended
 *   - Rationale: High enough to skip Vision for very confident matches,
 *     but low enough to still run Vision for ambiguous cases
 * 
 * SKIP_VISION_MARGIN_THRESHOLD (default: 0.03)
 *   - Range: 0.0-0.1 (set to 0 to disable)
 *   - Rationale: Ensures top match is significantly better than second match,
 *     reducing false positives from near-ties
 */

module.exports = {
  shouldSkipVisionDecision,
  SKIP_VISION_EMBEDDING_THRESHOLD,
  SKIP_VISION_MARGIN_THRESHOLD,
};

